<?php

	$id=$_GET['id_rdv'];
	include_once '../ConnexionBD.php';
	 //$bdd = new PDO('mysql:host=127.0.0.1;dbname=toc_toc_medoc-3', 'root', '');


    $sqldelete="DELETE FROM mesrndvs WHERE id_rdv='$id'";
	$statement=$bdd->prepare($sqldelete);
	$statement->execute();
	
	header('location:Admin.php');
?>