<?php

	$id=$_GET['id_medoc'];
	include_once '../ConnexionBD.php';
	 //$bdd = new PDO('mysql:host=127.0.0.1;dbname=toc_toc_medoc-3', 'root', '');


    $sqldelete="DELETE FROM mes_traitement WHERE id_medoc='$id'";
	$statement=$bdd->prepare($sqldelete);
	$statement->execute();
	
	header('location:Admin.php');
?>