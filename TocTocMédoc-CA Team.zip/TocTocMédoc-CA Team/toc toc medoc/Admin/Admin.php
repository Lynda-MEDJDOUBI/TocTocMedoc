<?php
session_start();

//$bdd = new PDO('mysql:host=127.0.0.1;dbname=toc_toc_medoc-3', 'root', '');

$emailpseudo=$_SESSION['mail']; 
include_once '../ConnexionBD.php'; // l'appel a la connexion avec la base de données
 
		
$pseudoafficher ="SELECT * FROM membres WHERE mail= '$emailpseudo'";
$statement = $bdd->prepare($pseudoafficher);
$statement->execute(array(':pseudo' => $pseudoafficher));
 
if(isset($_Get['supprime']) AND !empty($_GET['supprime'])){
	$supprime = (int) $_GET['supprime'];
	
	$req = $bdd->prepare('DELETE FROM membres WHERE id = ?');
	$req->execute(array($supprime));
}

// pour afficher le nombre de patient
$nombrepatient ="SELECT count(*) as nbpatient FROM membres";
$statementnombre= $bdd->prepare($nombrepatient);
$statementnombre->execute();
$donneesNombrePatient =$statementnombre->fetch();

  if(isset($_POST['AjouterQuestion']))
		   {
			 $id_Q=$_POST['id_Q'];
				$question=$_POST['question'];
					
					   

				   
			 $sqlInsert ="INSERT INTO questions (id_Q, question, réponse) VALUES(:id_Q, :question, :réponse)";
			 $statement = $bdd->prepare($sqlInsert);
	         $statement->execute(array(':id_Q' => $id_Q, ':question' => $question));
			    if($statement->rowCount() == 1)
					 {
						echo '<script>alert("insertion avec succ?")</script>';
				 }
					 else
					 {
						echo '<script>alert("Erreur d insertion")</script>';
					}
							   
		   }



	   
		   
		   
?>
<!DOCTYPE html>

<html>

  	<head>
			<title>Administrateur</title>
			<meta charset="utf8">
			
			<!-- Framwork--> 
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

			
			
			<!-- Polices -->
			<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
			<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
			<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
			<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
			<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
			<!-- CSS -->
			
			<link rel="stylesheet" href="../CSS/vendors/bootstrap.min.css">
			

		   <!-- Fontfaces CSS-->
		   	<link href="css/font-face.css" rel="stylesheet" media="all">
			<link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
			<link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
			<link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
			<!-- Bootstrap CSS-->
			<link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
			<!-- Vendor CSS-->
			<link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
			<link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
			<link href="vendor/wow/animate.css" rel="stylesheet" media="all">
			<link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
			<link href="vendor/slick/slick.css" rel="stylesheet" media="all">
			<link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
			<link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
			<!-- Main CSS-->
			

        	<style>
								
				/* Header*/

				header{
					height: 90px;
					padding: 0;
					border-bottom: 1px solid #000;
					
					list-style-type: none;
					overflow: hidden;
					background-color: #333;
				
				}

				header .logo img{
					font-size: 35px;
					height: 100px;
					width: 280px;
					color: white;
					/*margin: 0 10px;*/
					margin-top:0;
					margin-bottom: 60px;
					background-color: transparent;
				
				}

				header nav .nav-list{
					list-style: none;
					/*placer les lien de la nav sur une meme ligne */
					display: flex;
					justify-content: space-around;
					margin-bottom: 0;
					margin-top: 0;
					position: fixed; 
				
				}

				header i.icon{
					position: absolute;
					right: 25px;
					top: 25px;
					/*z-index: 10;*/
					display: none;
				}

				header nav .nav-list .list a{
					display: block;
					padding: 33px 40px;
					/*margin: 0px 25px;*/
					text-decoration: none;
					transition: all 0.3s ease-in-out;
					color: white;
					/*border: 1px solid black;
					border-radius: 5px;*/
					height: 90px;
					text-align: center;
					/*padding: 14px 16px;*/
					text-decoration: none;
				}

				header nav .nav-list .list a:hover{
					text-decoration: none;
					background-color: #111;
				}

				/* css de la formulaire */
        </style>
		</head>
	<body>
	<header >
			
		<!-- Hearder -->
		<header  class="container-fluid header">
			<div class="container">
				<!-- on va créer une ligne -->   
				<div class="row">
					<!-- Bars icon for nav -->
					<i class="icon far fa-bars"></i>  
					<!-- logo -->
					<div class="col-md-3 col-xs-12 col-sm-12 col-lg-3">
						<div class="logo">
							<!--<h2>Toc Toc Médoc</h2>-->
							<img src="../Image/logo2.png">
						</div>
					</div>
					
					<!-- Navigation du site -->
					<nav class="col-md-9 col-xs-12 col-sm-12 col-lg-9">
						<ul class="nav-list">
							<li class="list"><a href="#ProfilAdmin">Admin</a></li>
							<li class="list"><a href="#VisualiserPatient">Patients</a></li>
							<li class="list"><a href="#VisualiserRdv">Rendez-vous</a></li>
							<li class="list"><a href="#VisualiserTrait">Traitements</a></li>
							<li class="list"><a href="#VisualiserQuestions">Questions</a></li>
							<li class="list"><a href="../Deconnexion.php">Deconnexion</a></li>

						
						
						</ul>
					</nav>
					
				</div>
			</div>
    	</header> 

			

		</header> </br>
		<div class="container-fluid p-0">
			<section>
			<div class="container">
			<div class="row">
			  <div class="col-lg-12 text-center">
			 
			   <?php
			 
			  while ($donnees = $statement->fetch())
					{
				echo '<h2 class="section-heading text-uppercase"> Administrateur de toc-toc-medoc  :'.$donnees['pseudo'].'</h2>';
					}
			   ?>
				<!-- <h3 class="section-subheading text-muted">n'h?iter pas ?nous contacter pour tout renseignement.</h3> -->
			  </div>
			</div></br>
			
		   <div class="row">
			<div class="col-sm-6">
				<div class="equipe">
				  <h4>Yao SOGADZI</h4>
				  <p class="text-muted">Enseignant à l'université Paris 13 Villetaneuse</p>
				  <p class="text-muted">Matser 1 Informatique Institut Galilée - Université Paris 13 .</p>
				</div>
			</div>
			 
		   </div>
			
		 
		   </div>
		   <div class="row">
		 
		
								<div class="resume-section p-3 p-lg-5 d-flex flex-column">
									
												<div class="table-detail">
													<!-- <div class="iconbox bg-info"> -->
														<i class="fa fa-users" style="font-size:48px"></i>
													<!-- </div> -->
												</div>

												<div class="table-detail">
												
													<h2 class=""mb-5"">Nombre de Patients :</h2>
													<h4 class="m-t-0 m-b-5"><b><?php echo $donneesNombrePatient['nbpatient']?></b></h4>
												
													
												</div>
											  

								</div>
			</div> 
		</section>
		
		<section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserPatient">
		<h2 class="mb-5">La liste Des Patients </h2>
		
		
		 
		 <div class="fresh-table">
			<table id="fresh-table" class="table">
			<?php
			
			$SqlAficherJoueurs="SELECT * FROM membres";
			$statementAfficherJoueurs= $bdd->prepare($SqlAficherJoueurs);
			$statementAfficherJoueurs->execute();
			
			$afficherpatient ="SELECT * FROM membres";
			$statementafficherpatient= $bdd->prepare($afficherpatient);
			$statementafficherpatient->execute();
			?>
			 
			 
							<thead>
								<th>identifiant</th>
								<th  data-sortable="true">Pseudo</th>
								<th  data-sortable="true">E-mail</th>
							</thead>
							<tbody>
			  <?php
							  $mailAdmin= 'admin@gmail.com';
							  $mailAdmin2= 'admin2@gmail.com';
							while(($donnees = $statementafficherpatient->fetch()) )
			 {
			   ?>     
			   		<?php  if(($donnees['mail'] != $mailAdmin) && ($donnees['mail'] != $mailAdmin2)){ ?>
			               		<tr>
									<td><?php echo $donnees['id'] ?></td>
									<td><?php echo $donnees['pseudo']?></td>
									<td><?php echo $donnees['mail'] ?></td>
									<td><a href="supprimerPatient.php?mail=<?php echo $donnees['mail'] ?>" onclick="return confirm('voulez-vous supprimer ce patient ? o_O!')" role= "button" id="supprime"><i class="fa fa-times"></i> supprimer</a></td>
									
								</tr>
					<?php } ?>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>

		  	
		<section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserRdv">
		<h2 class="mb-5">La liste Des Rendez-Vous </h2>
		
		
		 
		 <div class="fresh-table">
			<table id="fresh-table" class="table">
			<?php
			
			
			$afficherRdv ="SELECT * FROM mesrndvs";
			$statementafficherRdv= $bdd->prepare($afficherRdv);
			$statementafficherRdv->execute();
			?>
			 
			 
							<thead>
								<th>identifiant</th>
								<th  data-sortable="true">Id Patient</th>
								<th  data-sortable="true">Date</th>
								<th  data-sortable="true">Heure</th>
								<th  data-sortable="true">Médecin</th>
								<th  data-sortable="true">Adresse</th>
							</thead>
							<tbody>
			  <?php
							while($donnees = $statementafficherRdv->fetch())
			 {
			   ?>                 <tr>
			   						<td><?php echo $donnees['id_rdv'] ?></td>
									<td><?php echo $donnees['id_m'] ?></td>
									<td><?php echo $donnees['date'] ?></td>
									<td><?php echo $donnees['heure'] ?></td>
									<td><?php echo $donnees['medecin'] ?></td>
									<td><?php echo $donnees['adresse'] ?></td>
									<td><a href="supprimerRdv.php?id_rdv=<?php echo $donnees['id_rdv'] ?>" onclick="return confirm('voulez-vous supprimer ce rendez-vous ? o_O!')" role= "button" id="supprime"><i class="fa fa-times"></i> supprimer</a></td>
									
								</tr>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>

		    	
		<section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserTrait">
		<h2 class="mb-5">La liste Des Traitements </h2>
		
		
		 
		 <div class="fresh-table">
			<table id="fresh-table" class="table">
			<?php
			
			
			$afficherTrait ="SELECT * FROM mes_traitement";
			$statementafficherTrait= $bdd->prepare($afficherTrait);
			$statementafficherTrait->execute();
			?>
			 
			 
							<thead>
								<th>identifiant</th>
								<th  data-sortable="true">Id Patient</th>
								<th  data-sortable="true">Médicament</th>
								<th  data-sortable="true">Type prise</th>
								<th  data-sortable="true">Date début</th>
								<th  data-sortable="true">Date fin</th>
							</thead>
							<tbody>
			  <?php
							while($donnees = $statementafficherTrait->fetch())
			 {
			   ?>                 <tr>
			   						<td><?php echo $donnees['id_medoc'] ?></td>
									<td><?php echo $donnees['idt'] ?></td>
									<td><?php echo $donnees['nom_medoc'] ?></td>
									<td><?php echo $donnees['type_prise'] ?></td>
									<td><?php echo $donnees['date_debut'] ?></td>
									<td><?php echo $donnees['date_fin'] ?></td>
									<td><a href="supprimerTrait.php?id_medoc=<?php echo $donnees['id_medoc'] ?>" onclick="return confirm('voulez-vous supprimer ce traitement ? o_O!')" role= "button" id="supprime"><i class="fa fa-times"></i> supprimer</a></td>
									
								</tr>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>
		  
		  <section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserQuestions">
		  <h2 class="mb-5">La liste Des Questions</h2>
		 

		
		 
		 <div class="fresh-table toolbar-color-orange">
			<table id="fresh-table" class="table">
			<?php
			
			$SqlAficherQuestion="SELECT * FROM questions";
			$statementAfficherQuestion= $bdd->prepare($SqlAficherQuestion);
			$statementAfficherQuestion->execute();
			?>
			 
			 
							<thead>
							  
							  <th  data-sortable="true">Ident_Qst</th>
							  <th  data-sortable="true">Questions</th>
							  
							</thead>
							<tbody>
			  <?php
							while($donnees = $statementAfficherQuestion->fetch())
			 {
			   ?>                 <tr>
									<td><?php echo $donnees['id_Q'] ?></td> 
									<td><?php echo $donnees['question'] ?></td>
									<td><a href="supprimerQst.php?id_Q=<?php echo $donnees['id_Q'] ?>" onclick="return confirm('voulez-vous supprimer cette question ? o_O!')" role= "button" id="supprime"><i class="fa fa-times"></i> supprimer</a></td>

									
								 </tr>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>
		   

		</div>   
	
    </body>

</html>
