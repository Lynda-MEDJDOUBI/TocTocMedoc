<?php
session_start();

$bdd = mysqli_connect("127.0.0.1", "root", "", "test");
//SYMPTOMES

//AJOUTE NOUVELLE LIGNE
if (isset($_POST['symptome'])) {
    $nom_commun           = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $description_symptome = htmlentities($_POST['description_symptome'], ENT_QUOTES, "UTF-8");
    
    $reqnom     = "SELECT * FROM SYMPTOMES  WHERE nom_commun = '$nom_commun'";
    $reqnom_run = mysqli_query($bdd, $reqnom);
    if (mysqli_num_rows($reqnom_run) == 0) {
        
        $query     = "INSERT INTO SYMPTOMES (nom_commun,description_symptome) VALUES ('$nom_commun','$description_symptome')";
        $query_run = mysqli_query($bdd, $query);
        if ($query_run) {
            $_SESSION['succes'] = "symptome ajouté";
            header("location:modif_symptomes.php");
            
        } else {
            $_SESSION['status'] = "Symptôme non ajouté";
            echo "<script>alert('Symptôme non ajouté!');
                window.location.href='modif_symptomes.php';
            </script>";
        }
        
    } else {
        $erreur = "Symptôme déjà existant!";
        echo "<script>alert('Symptôme déjà existant!');
    window.location.href='modif_symptomes.php';
    </script>";
        
    }
}

//MODIFIE LIGNE
if (isset($_POST['symptome_update_btn'])) {
    
    $edit_id = $_POST['update_id'];
    $nom     = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $desc    = htmlentities($_POST['description_symptome'], ENT_QUOTES, "UTF-8");
    
    $query     = "UPDATE SYMPTOMES SET nom_commun = '$nom', description_symptome = '$desc' WHERE id_symptome = $edit_id";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "symptome edité";
        header("location:modif_symptomes.php");
    } else {
        $erreur = "Erreur!";
        echo "<script>alert('Erreur de modification!');
    window.location.href='modif_symptomes.php';
    </script>";
    }
}

//SUPPRIME LIGNE
if (isset($_POST['symptome_delete_btn'])) {
    $id_symptome = $_POST['delete_id'];
    $query       = "DELETE FROM SYMPTOMES  WHERE id_symptome = '$id_symptome'";
    $query_run   = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "symptome supprimé";
        header("location:modif_symptomes.php");
    } else {
        $_SESSION['status'] = "Symptôme non supprimé";
        echo "<script>alert('Symptôme non supprimé!');
    window.location.href='modif_symptomes.php';
    </script>";
    }
}



//REMEDES

//AJOUTE NOUVELLE LIGNE
if (isset($_POST['remede'])) {
    $nom_commun         = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $description_remede = htmlentities($_POST['description_remede'], ENT_QUOTES, "UTF-8");
    $classe             = htmlentities($_POST['classe'], ENT_QUOTES, "UTF-8");
    $reqnom             = "SELECT * FROM REMEDES  WHERE nom_remede = '$nom_commun'";
    $reqnom_run         = mysqli_query($bdd, $reqnom);
    
    if (mysqli_num_rows($reqnom_run) == 0) {
        
        $query     = "INSERT INTO REMEDES (nom_remede,description_remede,classe_remede) VALUES ('$nom_commun','$description_remede','$classe')";
        $query_run = mysqli_query($bdd, $query);
        if ($query_run) {
            $_SESSION['succes'] = "remede ajouté";
            header("location:modif_remedes.php");
            
        } else {
            $_SESSION['status'] = "remede non ajouté";
            echo "<script>alert('Remède non ajouté!');
                window.location.href='modif_remedes.php';
            </script>";
        }
        
    } else {
        $erreur = "Remède déjà existant!";
        echo "<script>alert('Remède déjà existant!');
    window.location.href='modif_remedes.php';
    </script>";
    }
}

//MODIFIE LIGNE
if (isset($_POST['remede_update_btn'])) {
    
    $edit_id = $_POST['update_id'];
    $nom     = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $desc    = htmlentities($_POST['description_remede'], ENT_QUOTES, "UTF-8");
    $classe  = htmlentities($_POST['classe_remede'], ENT_QUOTES, "UTF-8");
    
    $query     = "UPDATE REMEDES SET nom_remede = '$nom', description_remede = '$desc', classe_remede = '$classe' WHERE id_remede = $edit_id";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "remede edité";
        header("location:modif_remedes.php");
    } else {
        $erreur = "Erreur!";
        echo "<script>alert('Erreur de modification!');
    window.location.href='modif_remedes.php';
    </script>";
    }
}


//SUPPRIME LIGNE
if (isset($_POST['remede_delete_btn'])) {
    
    $id_remede = $_POST['delete_id'];
    
    $query     = "DELETE FROM REMEDES  WHERE id_remede = '$id_remede'";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "remède supprimé";
        header("location:modif_remedes.php");
    } else {
        $_SESSION['status'] = "Remède non supprimé";
        echo "<script>alert('Remède non supprimé!');
    window.location.href='modif_remedes.php';
    </script>";
    }
}




//SOIGNE

//AJOUTE NOUVELLE LIGNE
if (isset($_POST['soigne'])) {
    $remede     = $_POST['remedeS'];
    $symptome   = $_POST['symptomeS'];
    $posologie  = htmlentities($_POST['posologie'], ENT_QUOTES, "UTF-8");
    $reqnom     = "SELECT * FROM SOIGNE  WHERE id_remede = '$remede' AND id_symptome = '$symptome'";
    $reqnom_run = mysqli_query($bdd, $reqnom);
    
    if (mysqli_num_rows($reqnom_run) == 0) {
        $reqnom2     = "SELECT * FROM REMEDES WHERE id_remede = '$remede'";
        $reqnom2_run = mysqli_query($bdd, $reqnom2);
        if (mysqli_num_rows($reqnom2_run) != 0) 
		{
            $reqnom3     = "SELECT * FROM symptomes  WHERE id_symptome = '$symptome'";
            $reqnom3_run = mysqli_query($bdd, $reqnom3);
            if (mysqli_num_rows($reqnom3_run) != 0) {
                $query     = "INSERT INTO soigne (id_remede,id_symptome,posologie) VALUES ('$remede','$symptome','$posologie')";
                $query_run = mysqli_query($bdd, $query);
                if ($query_run) 
				{
                    $_SESSION['succes'] = "soigne ajouté";
                    header("location:modif_soigne.php");
                    
                } else {
                    $_SESSION['status'] = "Soigne non ajouté";
                    echo "<script>alert('Liaison non ajouté!');
                window.location.href='modif_soigne.php';
            </script>";
                }
            }
			else {
                    $_SESSION['status'] = "symptome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_soigne.php';
            </script>";
                }
        }
		else {
                    $_SESSION['status'] = "Remède inexistant";
                    echo "   
					<script>alert('Remède inexistant!');
                window.location.href='modif_soigne.php';
            </script>";
                }
    } else {
        $erreur = "Soigne déjà existant!";
        echo "<script>alert('Liaison déjà existante!');
    window.location.href='modif_soigne.php';
    </script>";
        
    }
}

//MODIFIE LIGNE
if (isset($_POST['soigne_update_btn'])) {
    $edit_id1  = $_POST['update_id1'];
    $edit_id2  = $_POST['update_id2'];
    $remede    = $_POST['remedeS'];
    $symptome  = $_POST['symptomeS'];
    $posologie = htmlentities($_POST['posologie'], ENT_QUOTES, "UTF-8");
    
    $reqnom2 = "SELECT * FROM REMEDES  WHERE id_remede = '$remede'";  
    $reqnom2_run = mysqli_query($bdd, $reqnom2);
    echo mysqli_num_rows($reqnom2_run);
    if (mysqli_num_rows($reqnom2_run) != 0) {
        $reqnom3     = "SELECT * FROM SYMPTOMES  WHERE id_symptome = '$symptome'";
        $reqnom3_run = mysqli_query($bdd, $reqnom3);
        if (mysqli_num_rows($reqnom3_run) != 0) {
            $query     = "UPDATE soigne SET id_remede = '$remede', id_symptome = '$symptome', posologie = '$posologie' WHERE id_remede = $edit_id1 AND id_symptome = $edit_id2";
            $query_run = mysqli_query($bdd, $query);
            
            if ($query_run) {
                $_SESSION['succes'] = "soigne edité";
                header("location:modif_soigne.php");
            }
			else {
        $erreur = "Erreur!";
        echo "<script>alert('Erreur de modification!');
    window.location.href='modif_soigne.php';
    </script>";
    }
        }
		else {
                    $_SESSION['status'] = "symptome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_soigne.php';
            </script>";
                }
        }
		else {
                    $_SESSION['status'] = "Remède inexistant";
                    echo "   
					<script>alert('Remède inexistant!');
                window.location.href='modif_soigne.php';
            </script>";
                }
    } 



//SUPPRIME LIGNE
if (isset($_POST['soigne_delete_btn'])) {
    
    $id1       = $_POST['delete_id1'];
    $id2       = $_POST['delete_id2'];
    $query     = "DELETE FROM SOIGNE WHERE id_remede= '$id1' AND  id_symptome= '$id2'";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "soigne supprimé";
        header("location:modif_soigne.php");
    } else {
        $_SESSION['status'] = "soigne non supprimé";
        echo "<script>alert('Liaison non supprimé!');
    window.location.href='modif_soigne.php';
    </script>";
    }
}



//FAIT PARTIE DE 

//AJOUTE NOUVELLE LIGNE
if (isset($_POST['fpd'])) {
    $syndrome   = $_POST['syndromeF'];
    $symptome   = $_POST['symptomeF'];
    $reqnom     = "SELECT * FROM fait_partie_de  WHERE id_syndrome = '$syndrome' AND id_symptome = '$symptome'";
    $reqnom_run = mysqli_query($bdd, $reqnom);
    
    if (mysqli_num_rows($reqnom_run) == 0) {
        $reqnom2     = "SELECT * FROM syndromes  WHERE id_syndrome = '$syndrome'";
        $reqnom2_run = mysqli_query($bdd, $reqnom2);
        if (mysqli_num_rows($reqnom2_run) != 0) {
            $reqnom3     = "SELECT * FROM symptomes  WHERE id_symptome = '$symptome'";
            $reqnom3_run = mysqli_query($bdd, $reqnom3);
            if (mysqli_num_rows($reqnom3_run) != 0) {
                $query     = "INSERT INTO fait_partie_de (id_syndrome,id_symptome) VALUES ('$syndrome','$symptome')";
                $query_run = mysqli_query($bdd, $query);
                if ($query_run) {
                    $_SESSION['succes'] = "liaison ajouté";
                    header("location:modif_fait.php");
                    
                } else {
                    $_SESSION['status'] = "liaison non ajouté";
                    echo "<script>alert('Liaison non ajouté!');
    window.location.href='modif_fait.php';
    </script>";
                }
            }
			else {
                    $_SESSION['status'] = "symptome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_fait.php';
            </script>";
                }
        }
		else {
                    $_SESSION['status'] = "syndrome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_fait.php';
            </script>";
                }
    } else {
        $erreur = "liaison déjà existante!";
        echo "<script>alert('Liaison déjà existante!');
    window.location.href='modif_fait.php';
    </script>";
    }
}

//MODIFIE LIGNE
if (isset($_POST['fpd_update_btn'])) {
    
    $edit_id1 = $_POST['update_id1'];
    $edit_id2 = $_POST['update_id2'];
    $syndrome = $_POST['syndromeF'];
    $symptome = $_POST['symptomeF'];
    
    $reqnom2     = "SELECT * FROM syndromes  WHERE id_syndrome = '$syndrome'";
    $reqnom2_run = mysqli_query($bdd, $reqnom2);
    if (mysqli_num_rows($reqnom2_run) != 0) {
        $reqnom3     = "SELECT * FROM symptomes  WHERE id_symptome = '$symptome'";
        $reqnom3_run = mysqli_query($bdd, $reqnom3);
        if (mysqli_num_rows($reqnom3_run) != 0) {
            $query     = "UPDATE fait_partie_de SET id_syndrome = $syndrome, id_symptome = '$symptome' WHERE id_syndrome = $edit_id1 AND id_symptome = $edit_id2";
            $query_run = mysqli_query($bdd, $query);
            
            if ($query_run) {
                $_SESSION['succes'] = "liaison edité";
                header("location:modif_fait.php");
            }
			else {
        $erreur = "liaison non modifiée!";
        echo "<script>alert('Liaison non modifiée!');
    window.location.href='modif_fait.php';
    </script>";
    }
        }
		else {
                    $_SESSION['status'] = "symptome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_fait.php';
            </script>";
                }
        }
		else {
                    $_SESSION['status'] = "syndrome inexistant";
                    echo "<script>alert('Symptome inexistant!');
                window.location.href='modif_fait.php';
            </script>";
                }
    }

//SUPPRIME LIGNE
if (isset($_POST['fpd_delete_btn'])) {
    
    $id1       = $_POST['delete_id1'];
    $id2       = $_POST['delete_id2'];
    $query     = "DELETE FROM fait_partie_de  WHERE id_syndrome= '$id1' AND  id_symptome= '$id2'";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "liaison supprimée";
        header("location:modif_fait.php");
    } else {
        $_SESSION['status'] = "liaison non supprimée";
        echo "<script>alert('liaison non supprimée!');
    window.location.href='modif_fait.php';
    </script>";
    }
}





//SYNDROME

//AJOUTE NOUVELLE LIGNE
if (isset($_POST['syndrome'])) {
    $nom_commun           = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $description_syndrome = htmlentities($_POST['description_syndrome'], ENT_QUOTES, "UTF-8");
    $classe               = htmlentities($_POST['classe'], ENT_QUOTES, "UTF-8");
    $reqnom               = "SELECT * FROM syndromes  WHERE nom_syndrome = '$nom_commun'";
    $reqnom_run           = mysqli_query($bdd, $reqnom);
    
    if (mysqli_num_rows($reqnom_run) == 0) {
        
        $query     = "INSERT INTO syndromes (nom_syndrome,description_syndrome,classification) VALUES ('$nom_commun','$description_syndrome','$classe')";
        $query_run = mysqli_query($bdd, $query);
        if ($query_run) {
            $_SESSION['succes'] = "syndrome ajouté";
            header("location:modif_syndromes.php");
            
        } else {
            $_SESSION['status'] = "syndrome non ajouté";
            echo "<script>alert('Syndrome non ajouté!');
    window.location.href='modif_syndromes.php';
    </script>";
        }
        
    } else {
        $erreur = "Syndrome déjà existant !";
        echo "<script>alert('Syndrome déjà existant!');
    window.location.href='modif_syndromes.php';
    </script>";
    }
}

//SUPPRIME LIGNE
if (isset($_POST['syndrome_delete_btn'])) {
    
    $id_syndrome = $_POST['delete_id'];
    
    $query     = "DELETE FROM syndromes  WHERE id_syndrome = '$id_syndrome'";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "syndrome supprimé";
        header("location:modif_syndromes.php");
    } else {
        $_SESSION['status'] = "Syndrome non supprimé";
        echo "<script>alert('Syndrome non supprimé!');
    window.location.href='modif_syndromes.php';
    </script>";
    }
}


//MODIFIE LIGNE
if (isset($_POST['syndrome_update_btn'])) {
    
    $edit_id = $_POST['update_id'];
    $nom     = htmlentities($_POST['nom_commun'], ENT_QUOTES, "UTF-8");
    $desc    = htmlentities($_POST['description_syndrome'], ENT_QUOTES, "UTF-8");
    $classe  = htmlentities($_POST['classe'], ENT_QUOTES, "UTF-8");
    
    $query     = "UPDATE syndromes SET nom_syndrome = '$nom', description_syndrome = '$desc', classification = '$classe' WHERE id_syndrome = $edit_id";
    $query_run = mysqli_query($bdd, $query);
    
    if ($query_run) {
        $_SESSION['succes'] = "syndrome edité";
        header("location:modif_syndromes.php");
    } else {
        $_SESSION['status'] = "Syndrome non edité";
        echo "<script>alert('Syndrome non edité!');
    window.location.href='modif_syndromes.php';
    </script>";
    }
}
?>