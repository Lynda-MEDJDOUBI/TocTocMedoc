<?php
    //session_start(); 
    $emailpseudo=$_SESSION['mail']; 
    include_once 'ConnexionBD.php';
    $idt = "SELECT id FROM membres WHERE mail= '$emailpseudo'";
    $statement1 = $bdd->prepare($idt);
    $statement1->execute(array(':id' => $idt));
    $donnees = $statement1->fetch();
    $idez = $donnees['id'];

    $requeteUser= $bdd->prepare("SELECT * FROM mesrndvs WHERE id_m=?");
    $requeteUser -> execute(array($idez));

    while($row = $requeteUser->fetch()){
            $time = time()/*strtotime("+2 hours")*/;
            $dis = strtotime($row['date'].$row['heure'].'-2 hours') - $time;
            if($dis > 0){
                echo "<script>
                    setTimeout(\"alert('Vous avez un rendez-vous avec le docteur ".$row['medecin']." à : ".$row['heure']."');\",$dis*1000);
                    </script>";;
            }
    }

?>