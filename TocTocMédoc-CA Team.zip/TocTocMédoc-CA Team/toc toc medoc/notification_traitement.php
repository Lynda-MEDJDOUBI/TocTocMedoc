<?php
    //session_start(); 
    $emailpseudo=$_SESSION['mail']; 
    include_once 'ConnexionBD.php';
    $idt = "SELECT id FROM membres WHERE mail= '$emailpseudo'";
    $statement1 = $bdd->prepare($idt);
    $statement1->execute(array(':id' => $idt));
    $donnees = $statement1->fetch();
    $idez = $donnees['id'];

    $requeteUser= $bdd->prepare("SELECT * FROM mes_traitement WHERE idt=?");
    $requeteUser -> execute(array($idez));
    //echo date('Y-m-d H:i:s');

    /* test fonction distance_date()
    $days = distance_date(date("Y-m-d"),"2020-04-30");
    echo $days;*/

    while($row = $requeteUser->fetch()){
        if($row["lundi"] == 0 && $row["mardi"] == 0 && $row["mercredi"] == 0 && $row["jeudi"] == 0 && $row["vendredi"] == 0 && $row["samedi"] == 0 && $row["dimanche"] == 0){
            for($i = 0; $i < distance_date($row['date_debut'],$row['date_fin']);$i++){
                if($row['matin'] != 0){
                    $dateMatin = strtotime($row['date_debut']." 07:00:00".'+'.$i.'days');
                    alert($dateMatin,$row['nom_medoc'],$row['matin']);
                }
                if($row['midi'] != 0){
                    $dateMidi = strtotime($row['date_debut']." 12:00:00".'+'.$i.'days');
                    alert($dateMidi,$row['nom_medoc'],$row['midi']);
                }
                if($row['soir'] != 0){
                    $dateSoir = strtotime($row['date_debut']." 18:00:00".'+'.$i.'days');
                    alert($dateSoir,$row['nom_medoc'],$row['soir']);
                }
            }
        }
        else{
            $jour = array();
            $num = 0;
            if($row["lundi"] == 1){
                $jour[$num] = 1; 
                $num++;
            }
            if($row["mardi"] == 1){
                $jour[$num] = 2; 
                $num++;
            }
            if($row["mercredi"] == 1){
                $jour[$num] = 3; 
                $num++;
            }
            if($row["jeudi"] == 1){
                $jour[$num] = 4; 
                $num++;
            }
            if($row["vendredi"] == 1){
                $jour[$num] = 5; 
                $num++;
            }
            if($row["samedi"] == 1){
                $jour[$num] = 6; 
                $num++;
            }
            if($row["dimanche"] == 1){
                $jour[$num] = 7; 
                $num++;
            }
            /* le jour quand il faut prendre le médicament
            for($k = 0 ; $k <count($jour) ;$k++){
                echo $jour[$k];
            }*/
            for($i = 0; $i < distance_date($row['date_debut'],$row['date_fin']);$i++){
                if($row['matin'] != 0){
                    $dateMatin = strtotime($row['date_debut']." 07:00:00".'+'.$i.'days');
                    for($k=0;$k <count($jour) ;$k++){
                        if(date("w",$dateMatin) == $jour[$k])
                            alert($dateMatin,$row['nom_medoc'],$row['matin']);
                    }
                }
                if($row['midi'] != 0){
                    $dateMidi = strtotime($row['date_debut']." 12:00:00".'+'.$i.'days');
                    for($k=0;$k <count($jour) ;$k++){
                        if(date("w",$dateMidi) == $jour[$k])
                            alert($dateMidi,$row['nom_medoc'],$row['midi']);
                    }
                }
                if($row['soir'] != 0){
                    $dateSoir = strtotime($row['date_debut']." 18:00:00".'+'.$i.'days');
                    for($k=0;$k <count($jour) ;$k++){
                        if(date("w",$dateSoir) == $jour[$k])
                            alert($dateSoir,$row['nom_medoc'],$row['soir']);
                    }
                }
            }
            //echo date("w",strtotime($row['date_debut']." 07:00:00".'+'.$i.'days'));
        }
    }

    function distance_date($debut,$fin){
        $d1 = strtotime($debut);
        $d2 = strtotime($fin);
        return (round($d2-$d1)/3600/24);
    }

    function alert($time2,$medicament,$quantite){
        $time = time();//strtotime("+2 hours");
        $dis = $time2 - $time;
        if($dis > 0){
            echo "<script>
                    setTimeout(\"alert('Il faut prendre votre médicament ".$medicament." avec quantité :".$quantite."');\",$dis*1000);
                </script>";
        }
    }

/* un test pour la notification du temps
    $time = strtotime("+2 hours");//time()
    $time2 = strtotime('2020-04-29 20:35:00');
    echo $time."<br>";
    echo $time2."<br>";
    $dis = $time2 - $time;
    echo date("Y-m-d H:i:s",$time)."<br>";
    echo date("Y-m-d H:i:s",$time2)."<br>";
    echo $dis."second";
    echo "<script>
         setTimeout(\"alert('hi');\",$dis*1000);
         </script>";*/
?>