Pour utiliser notre application web vous devez suivre les étapes suivantes:

1- Télécharger le serveur local Wamp si vous etes sur windows, Lamp si vous etes sur linux et Mamp si vous etes sur mac

2- Dézipper le projet TocTocMedoc.zip et le placer dans le dossier suivant wamp64/www/TocTocTocMedoc

3- Téléchargez le script toc_toc_medoc-3.sql et le script test.sql (c'est la base de données du groupe YAKHAR)

4- Accédez à vos base de données en allant sur PhpMyAdmin (tapez PhpMyAdmin sur la barre de recherche de votre navigateur, 
   le login c'est "root" et le mot de passe est vide)

5- Créez une nouvelle base de données qui s'appelle test.sql et importez la sur PhpMyAdmin

6- Importez le script toc_toc_medoc-3.sql sur votre base de données afin que toutes les tables de notres site soient crées 

7- Créez une nouvelle base de données qui s'appelle toc_toc_medoc-3.sql

8- Maintenant que tout est en place il suffit de taper http://localhost sur votre navigateur pour accéder au site

9- Vous pouvez créer de nouveaux utilisateurs en plus deceux qui sont déja inscrits 

10- Pour vous connecter en tant qu'admin de notre plateforme: 

	mail : admin@gmail.com
	mot de passe : admin

11- Pour vous connecter en tant qu'admin sur la partie du groupe YAKHAR:

	mail: admin2@gmail.com
	mot de passe : admin2

12- Pour tester les fonctionalitées de notre application ajoutez un nouvel utilisateur avec le formulaire d'inscription

13- connectez vous avec ce nouvel utilisateur via le formulaire de connexion

14- Une fois connecté, vous pouvez ajouter un nouveau traitement en allant dans la rubrique : Mes Traitement > Nouveau traitement 

15- Pour voir la l'historique de tous vos traitements allez dans la rubrique : Mes traitements > Tous mes traitements

16- Pour ajoiter un nouveau rendez-vous allez dans la rubrique : Mes rendez-vous > Nouveau Rendez-vous

17- Pour voir la l'historique de tous vos rendez-vous allez dans la rubrique : Mes rendez-vous > Tous mes rendez-vous 

18- Pour dialoguer avec le tchatbot allez dans la rubrique : Mon tchatbot

19- Pour tester l'alarme sur les traitements ajoutez un nouveau traitement avec des moments de prises et des jours de prise 
    et en faisant en sorte de cocher le jour actuel, l'alarme va sonner à 7h00 si vous avez définit une quantité matin, 
    à 12h00 si vous avez définit une quantité midi et à 18h00 si vous avez définit une quantité soir sur le formulaire. 

20- Attendez donc les heurs ci-dessus (selon les moments de prise de votre médicament) pour avoir une notification mais pour
    cela vous devez etre connecté sur le site. 

21- Pour tester l'alarme sur les rendez-vous ajoutez un nouveau rendez-vous et faites en sorte de choisir la date d'aujourd'hui 
    et n'oubliez pas que la notification vous sera envoyer 2h avant le rendez-vous donc si vous voulez tester l'application à 
    15h30 alors définissez l'heure du rendez-vous à 17H30. 

















