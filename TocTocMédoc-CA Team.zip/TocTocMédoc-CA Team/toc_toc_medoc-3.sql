-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 02 mai 2020 à 20:54
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `toc_toc_medoc-3`
--

-- --------------------------------------------------------

--
-- Structure de la table `chatbot`
--

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `user` longtext NOT NULL,
  `chatbot` longtext NOT NULL,
  `action` varchar(255) NOT NULL,
  `del_msg` tinyint(4) NOT NULL DEFAULT 1,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `chatbot`
--

INSERT INTO `chatbot` (`id`, `id_user`, `user`, `chatbot`, `action`, `del_msg`, `date`) VALUES
(78, 20, 'hi', 'hello', 'text', 0, '2020-04-29 15:58:35'),
(79, 20, 'how are you', 'I am fine, thank you ', 'text', 0, '2020-04-29 15:59:36'),
(80, 20, 'hi', 'hello', 'text', 0, '2020-04-29 19:57:12'),
(81, 20, 'quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query', 0, '2020-04-29 19:57:44'),
(82, 20, 's.dkjskj', ' Je suis désolé mais je ne sais pas exactement comment vous aider', 'text', 0, '2020-04-29 20:00:46'),
(83, 20, 'hi', 'hello', 'text', 0, '2020-04-30 12:47:26'),
(84, 20, 'peux tu m\'aider à trouver un itinéraire pour mon rendez-vous', 'Tes désirs sont des ordres !<a href=\"https://www.google.com/maps\" target=\"_blank\"> clique ici :)</a>', 'text', 0, '2020-04-30 12:47:58'),
(85, 20, 'hi', 'hello', 'text', 0, '2020-04-30 14:21:01'),
(86, 20, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text', 0, '2020-04-30 14:21:34'),
(87, 20, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text', 0, '2020-04-30 14:43:03'),
(88, 20, 'peux tu m\'aider à trouver un itinéraire pour mon rendez-vous', 'Tes désirs sont des ordres !<a href=\"https://www.google.com/maps\" target=\"_blank\"> clique ici :)</a>', 'text', 0, '2020-04-30 14:43:12'),
(89, 20, 'quel est le nom de mon médicament', 'echo $nom_medoc;', 'query', 0, '2020-04-30 14:43:25'),
(90, 20, 'quand est ce que mon traitement se termine', 'echo $date_fin;', 'query', 0, '2020-04-30 14:43:35'),
(91, 20, 'quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query', 0, '2020-04-30 14:43:48'),
(92, 29, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text', 0, '2020-04-30 15:26:17'),
(93, 29, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text', 1, '2020-04-30 15:45:18'),
(94, 29, 'quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query', 1, '2020-04-30 15:45:36');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE `membres` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `motdepasse` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `mail`, `motdepasse`) VALUES
(19, 'melin', 'melin@gmail.com', '209d5fae8b2ba427d30650dd0250942af944a0c9'),
(20, 'toto', 'toto@gmail.com', '209d5fae8b2ba427d30650dd0250942af944a0c9'),
(26, 'admin', 'admin@gmail.com', '7b2e9f54cdff413fcde01f330af6896c3cd7e6cd'),
(27, 'admin-YAKHAR', 'admin2@gmail.com', 'e08e3dc99acb2de37bb1610a0d27c7f90c1f3716'),
(29, 'Xiaotong', 'Xiaotong@gmail.com', '209d5fae8b2ba427d30650dd0250942af944a0c9');

-- --------------------------------------------------------

--
-- Structure de la table `mesrndvs`
--

CREATE TABLE `mesrndvs` (
  `id_rdv` int(11) NOT NULL,
  `id_m` int(11) NOT NULL,
  `date` date NOT NULL,
  `heure` time(6) NOT NULL,
  `medecin` varchar(100) NOT NULL,
  `specialite` varchar(50) NOT NULL,
  `adresse` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `mesrndvs`
--

INSERT INTO `mesrndvs` (`id_rdv`, `id_m`, `date`, `heure`, `medecin`, `specialite`, `adresse`) VALUES
(38, 29, '2020-04-30', '17:50:00.000000', 'Chich', 'dentiste', 'Paris'),
(39, 29, '2020-05-02', '20:30:00.000000', 'Amimer', 'Géneraliste', 'Bobigny'),
(40, 29, '2020-05-02', '21:30:00.047000', 'Amimer', 'Géneraliste', 'Bobigny'),
(41, 29, '2020-05-02', '21:27:00.730000', 'Assaraf David', 'ophtalmologiste', 'Drancy'),
(42, 29, '2020-05-07', '12:12:00.000000', 'TEST', 'TEST', 'TEST'),
(43, 29, '2020-05-07', '12:12:00.000000', 'TEST', 'TEST', 'TEST');

-- --------------------------------------------------------

--
-- Structure de la table `mes_traitement`
--

CREATE TABLE `mes_traitement` (
  `id_medoc` int(11) NOT NULL,
  `idt` int(11) NOT NULL,
  `type_prise` varchar(255) NOT NULL,
  `matin` int(11) NOT NULL,
  `midi` int(11) NOT NULL,
  `soir` int(11) NOT NULL,
  `nom_medoc` varchar(255) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `lundi` int(11) NOT NULL,
  `mardi` int(11) NOT NULL,
  `mercredi` int(11) NOT NULL,
  `jeudi` int(11) NOT NULL,
  `vendredi` int(11) NOT NULL,
  `samedi` int(11) NOT NULL,
  `dimanche` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `mes_traitement`
--

INSERT INTO `mes_traitement` (`id_medoc`, `idt`, `type_prise`, `matin`, `midi`, `soir`, `nom_medoc`, `date_debut`, `date_fin`, `lundi`, `mardi`, `mercredi`, `jeudi`, `vendredi`, `samedi`, `dimanche`) VALUES
(21, 28, 'Comprimé', 1, 1, 1, 'Doliprane', '2020-04-30', '2020-05-03', 1, 1, 1, 1, 0, 0, 0),
(26, 29, 'Comprimé', 1, 1, 1, 'Rumex', '2020-05-02', '2020-05-13', 1, 0, 0, 1, 0, 1, 1),
(25, 29, 'Comprimé', 1, 0, 2, 'Dafalgan', '2020-04-30', '2020-05-10', 1, 0, 1, 1, 0, 0, 1),
(24, 29, 'Comprimé', 0, 5, 1, 'Spasfon', '2020-05-01', '2020-05-09', 1, 0, 0, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE `questions` (
  `id_Q` int(11) NOT NULL,
  `question` longtext NOT NULL,
  `réponse` longtext NOT NULL,
  `action` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`id_Q`, `question`, `réponse`, `action`) VALUES
(5, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text'),
(6, 'peux tu m\'aider à trouver un itinéraire pour mon rendez-vous', 'Tes désirs sont des ordres !<a href=\"https://www.google.com/maps\" target=\"_blank\"> clique ici :)</a>', 'text'),
(7, 'Quel est le nom de mon médicament', 'echo $nom_medoc;', 'query'),
(8, 'quand est ce que mon traitement se termine', 'echo $date_fin;', 'query'),
(13, 'Quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `chatbot`
--
ALTER TABLE `chatbot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_,user` (`id_user`);

--
-- Index pour la table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `mesrndvs`
--
ALTER TABLE `mesrndvs`
  ADD PRIMARY KEY (`id_rdv`),
  ADD KEY `id_m` (`id_m`);

--
-- Index pour la table `mes_traitement`
--
ALTER TABLE `mes_traitement`
  ADD PRIMARY KEY (`id_medoc`);

--
-- Index pour la table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id_Q`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `chatbot`
--
ALTER TABLE `chatbot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT pour la table `membres`
--
ALTER TABLE `membres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT pour la table `mesrndvs`
--
ALTER TABLE `mesrndvs`
  MODIFY `id_rdv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT pour la table `mes_traitement`
--
ALTER TABLE `mes_traitement`
  MODIFY `id_medoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `questions`
--
ALTER TABLE `questions`
  MODIFY `id_Q` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `mesrndvs`
--
ALTER TABLE `mesrndvs`
  ADD CONSTRAINT `mesrndvs_ibfk_1` FOREIGN KEY (`id_m`) REFERENCES `membres` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
